//
//  FileManager.h
//  RSAEncryption
//
//  Created by 邵波 on 17/8/11.
//  Copyright © 2017年 邵波. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FileManager : NSObject
+ (SecKeyRef)getPublicKeyRefWithContentsOfFile:(NSString *)filePath;
+ (SecKeyRef)getPrivateKeyRefWithContentsOfFile:(NSString *)filePath password:(NSString*)password;
@end
