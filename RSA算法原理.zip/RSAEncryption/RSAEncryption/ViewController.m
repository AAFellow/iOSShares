//
//  ViewController.m
//  RSAEncryption
//
//  Created by 邵波 on 17/8/11.
//  Copyright © 2017年 邵波. All rights reserved.
//

#import "ViewController.h"
#import "RSAManager.h"

@interface ViewController ()
@property (nonatomic,strong) UITextView *contentTextView;
@property (nonatomic,strong) UILabel *encryptionLabel;
@property (nonatomic,strong) UILabel *dencryptionLabel;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _contentTextView = [[UITextView alloc] initWithFrame:CGRectMake(17, 15, CGRectGetWidth(self.view.frame)-34, 50)];
    
    NSString *contentPath = [[NSBundle mainBundle]pathForResource:@"content" ofType:nil];
    NSString *originalString = [NSString stringWithContentsOfFile:contentPath encoding:NSUTF8StringEncoding error:nil];
    
    //使用.der和.p12中的公钥私钥加密解密
    NSString *public_key_path = [[NSBundle mainBundle] pathForResource:@"public.der" ofType:nil];
    NSString *private_key_path = [[NSBundle mainBundle] pathForResource:@"private.p12" ofType:nil];
    
    NSString *encryptStr = [RSAManager encryptString:originalString publicKeyWithContentsOfFile:public_key_path];
    NSLog(@"加密前:%@", originalString);
    NSLog(@"加密后:%@", encryptStr);
    NSLog(@"解密后:%@", [RSAManager decryptString:encryptStr privateKeyWithContentsOfFile:private_key_path password:@"123"]);
//    _contentTextView.te
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
